--蜜蜂机器人
function c100317042.initial_effect(c)
	Debug.Message("「蜜蜂机器人」暂时无法使用！")
end
