--刚鬼 巨人食人魔
function c101001045.initial_effect(c)
	Debug.Message("「刚鬼 巨人食人魔」暂时无法使用！")
end
