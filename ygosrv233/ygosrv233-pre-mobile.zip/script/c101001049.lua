--星杯剑士 奥拉姆
function c101001049.initial_effect(c)
	Debug.Message("「星杯剑士 奥拉姆」暂时无法使用！")
end
