--防火龙
function c101001043.initial_effect(c)
	Debug.Message("「防火龙」暂时无法使用！")
end
