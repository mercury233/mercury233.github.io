--救援雪貂
function c101001029.initial_effect(c)
	Debug.Message("「救援雪貂」暂时无法使用！")
end
