--金毛妇
function c101001052.initial_effect(c)
	Debug.Message("「金毛妇」暂时无法使用！")
end
