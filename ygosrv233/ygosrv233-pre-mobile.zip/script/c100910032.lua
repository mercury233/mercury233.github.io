--怒気土器
--Dokidoki
--Script by nekrozar
function c100910032.initial_effect(c)
	--special summon
	local e1=Effect.CreateEffect(c)
	e1:SetDescription(aux.Stringid(100910032,0))
	e1:SetCategory(CATEGORY_SPECIAL_SUMMON)
	e1:SetType(EFFECT_TYPE_IGNITION)
	e1:SetRange(LOCATION_MZONE)
	e1:SetCountLimit(1,100910032)
	e1:SetCost(c100910032.spcost)
	e1:SetTarget(c100910032.sptg)
	e1:SetOperation(c100910032.spop)
	c:RegisterEffect(e1)
end
function c100910032.spcost(e,tp,eg,ep,ev,re,r,rp,chk)
	e:SetLabel(100)
	return true
end
function c100910032.cfilter(c,e,tp)
	return c:IsRace(RACE_ROCK) and c:IsDiscardable()
		and Duel.IsExistingMatchingCard(c100910032.spfilter,tp,LOCATION_DECK,0,1,nil,e,tp,c:GetOriginalAttribute(),c:GetOriginalLevel())
end
function c100910032.spfilter(c,e,tp,att,lv)
	return c:IsRace(RACE_ROCK) and c:GetOriginalAttribute()==att and c:GetOriginalLevel()==lv
		and (c:IsCanBeSpecialSummoned(e,0,tp,false,false) or c:IsCanBeSpecialSummoned(e,0,tp,false,false,POS_FACEDOWN))
end
function c100910032.sptg(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then
		if e:GetLabel()~=100 then return false end
		e:SetLabel(0)
		return Duel.GetLocationCount(tp,LOCATION_MZONE)>0
			and Duel.IsExistingMatchingCard(c100910032.cfilter,tp,LOCATION_HAND,0,1,nil,e,tp)
	end
	local g=Duel.DiscardHand(tp,c100910032.cfilter,1,1,REASON_COST+REASON_DISCARD,nil,e,tp)
	e:SetLabelObject(g:GetFirst())
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,nil,1,0,0)
end
function c100910032.spop(e,tp,eg,ep,ev,re,r,rp)
	local sg=e:GetLabelObject()
	if Duel.GetLocationCount(tp,LOCATION_MZONE)<=0 then return end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
	local g=Duel.SelectMatchingCard(tp,c100910032.spfilter,tp,LOCATION_DECK,0,1,1,nil,e,tp,sg:GetOriginalAttribute(),sg:GetOriginalLevel())
	local tc=g:GetFirst()
	if tc then
		local spos=0
		if tc:IsCanBeSpecialSummoned(e,0,tp,false,false) then spos=spos+POS_FACEUP_ATTACK end
		if tc:IsCanBeSpecialSummoned(e,0,tp,false,false,POS_FACEDOWN) then spos=spos+POS_FACEDOWN_DEFENSE end
		Duel.SpecialSummon(tc,0,tp,tp,false,false,spos)
		if tc:IsFacedown() then
			Duel.ConfirmCards(1-tp,tc)
		end
	end
end
