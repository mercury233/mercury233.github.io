--绝缘的落穴
function c101001075.initial_effect(c)
	Debug.Message("「绝缘的落穴」暂时无法使用！")
end
