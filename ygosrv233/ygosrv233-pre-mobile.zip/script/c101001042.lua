--DDD 怒涛大王 决策凯撒
function c101001042.initial_effect(c)
	Debug.Message("「DDD 怒涛大王 决策凯撒」暂时无法使用！")
end
