--DD 恶妖提丰
function c101001017.initial_effect(c)
	Debug.Message("「DD 恶妖提丰」暂时无法使用！")
end
