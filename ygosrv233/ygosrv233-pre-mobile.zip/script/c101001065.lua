--王车连接
function c101001065.initial_effect(c)
	Debug.Message("「王车连接」暂时无法使用！")
end
