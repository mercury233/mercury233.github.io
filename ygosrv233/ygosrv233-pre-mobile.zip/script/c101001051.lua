--電影の騎士ガイアセイバー
--Gaiasaber, the Video Knight
--Script by nekrozar
function c101001051.initial_effect(c)
	--link summon
	aux.AddLinkProcedure(c,nil,2)
	c:EnableReviveLimit()
end
