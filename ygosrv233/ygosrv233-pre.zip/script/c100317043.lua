--连接蜘蛛
function c100317043.initial_effect(c)
	Debug.Message("「连接蜘蛛」暂时无法使用！")
end
