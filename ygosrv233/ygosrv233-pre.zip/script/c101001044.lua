--淘气仙星·圣天使
function c101001044.initial_effect(c)
	Debug.Message("「淘气仙星·圣天使」暂时无法使用！")
end
