--不知火流 輪廻の陣
--Shiranui Style Reincarnation
--Script by nekrozar
function c100911074.initial_effect(c)
	--Activate
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_FREE_CHAIN)
	e1:SetTarget(c100911074.target)
	c:RegisterEffect(e1)
	--change code
	local e2=Effect.CreateEffect(c)
	e2:SetType(EFFECT_TYPE_SINGLE)
	e2:SetProperty(EFFECT_FLAG_SINGLE_RANGE)
	e2:SetCode(EFFECT_CHANGE_CODE)
	e2:SetRange(LOCATION_SZONE)
	e2:SetValue(40005099)
	c:RegisterEffect(e2)
	--no damage
	local e3=Effect.CreateEffect(c)
	e3:SetDescription(aux.Stringid(100911074,0))
	e3:SetType(EFFECT_TYPE_QUICK_O)
	e3:SetCode(EVENT_FREE_CHAIN)
	e3:SetRange(LOCATION_SZONE)
	e3:SetCost(c100911074.damcost)
	e3:SetTarget(c100911074.damtg)
	e3:SetOperation(c100911074.damop)
	c:RegisterEffect(e3)
	--to deck
	local e4=Effect.CreateEffect(c)
	e4:SetDescription(aux.Stringid(100911074,1))
	e4:SetCategory(CATEGORY_TODECK+CATEGORY_DRAW)
	e4:SetType(EFFECT_TYPE_QUICK_O)
	e4:SetProperty(EFFECT_FLAG_CARD_TARGET)
	e4:SetCode(EVENT_FREE_CHAIN)
	e4:SetRange(LOCATION_SZONE)
	e4:SetTarget(c100911074.tdtg)
	e4:SetOperation(c100911074.tdop)
	c:RegisterEffect(e4)
end
function c100911074.target(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chkc then return c100911074.tdtg(e,tp,eg,ep,ev,re,r,rp,0,chkc) end
	if chk==0 then return true end
	local b1=c100911074.damcost(e,tp,eg,ep,ev,re,r,rp,0)
		and c100911074.damtg(e,tp,eg,ep,ev,re,r,rp,0)
	local b2=c100911074.tdtg(e,tp,eg,ep,ev,re,r,rp,0)
	if (b1 or b2) and Duel.SelectYesNo(tp,94) then
		local op=0
		if b1 and b2 then
			op=Duel.SelectOption(tp,aux.Stringid(100911074,0),aux.Stringid(100911074,1))
		elseif b1 then
			op=Duel.SelectOption(tp,aux.Stringid(100911074,0))
		else
			op=Duel.SelectOption(tp,aux.Stringid(100911074,1))+1
		end
		if op==0 then
			c100911074.damcost(e,tp,eg,ep,ev,re,r,rp,1)
			c100911074.damtg(e,tp,eg,ep,ev,re,r,rp,1)
			e:SetCategory(0)
			e:SetProperty(0)
			e:SetOperation(c100911074.damop)
		else
			c100911074.tdtg(e,tp,eg,ep,ev,re,r,rp,1)
			e:SetCategory(CATEGORY_TODECK+CATEGORY_DRAW)
			e:SetProperty(EFFECT_FLAG_CARD_TARGET)
			e:SetOperation(c100911074.tdop)
		end
	else
		e:SetCategory(0)
		e:SetProperty(0)
		e:SetOperation(nil)
	end
end
function c100911074.damcost(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return e:GetHandler():IsAbleToRemoveAsCost() end
	Duel.Remove(e:GetHandler(),POS_FACEUP,REASON_COST)
end
function c100911074.damtg(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return e:GetHandler():GetFlagEffect(100911074)==0 end
	e:GetHandler():RegisterFlagEffect(100911074,RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_END,0,1)
end
function c100911074.damop(e,tp,eg,ep,ev,re,r,rp)
	if not e:GetHandler():IsRelateToEffect(e) then return end
	local e1=Effect.CreateEffect(e:GetHandler())
	e1:SetType(EFFECT_TYPE_FIELD)
	e1:SetCode(EFFECT_CHANGE_DAMAGE)
	e1:SetProperty(EFFECT_FLAG_PLAYER_TARGET)
	e1:SetTargetRange(1,0)
	e1:SetValue(0)
	e1:SetReset(RESET_PHASE+PHASE_END)
	Duel.RegisterEffect(e1,tp)
	local e2=e1:Clone()
	e2:SetCode(EFFECT_NO_EFFECT_DAMAGE)
	e2:SetReset(RESET_PHASE+PHASE_END)
	Duel.RegisterEffect(e2,tp)
end
function c100911074.tdfilter(c)
	return c:IsFaceup() and c:IsRace(RACE_ZOMBIE) and c:GetDefense()==0 and c:IsAbleToDeck()
end
function c100911074.tdtg(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chkc then return chkc:IsLocation(LOCATION_REMOVED) and chkc:IsControler(tp) and c100911074.tdfilter(chkc) end
	if chk==0 then return e:GetHandler():GetFlagEffect(100911074)==0
		and Duel.IsPlayerCanDraw(tp,1)
		and Duel.IsExistingTarget(c100911074.tdfilter,tp,LOCATION_REMOVED,0,2,nil) end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_TODECK)
	local g=Duel.SelectTarget(tp,c100911074.tdfilter,tp,LOCATION_REMOVED,0,2,2,nil)
	Duel.SetOperationInfo(0,CATEGORY_TODECK,g,2,0,0)
	Duel.SetOperationInfo(0,CATEGORY_DRAW,nil,0,tp,1)
	e:GetHandler():RegisterFlagEffect(100911074,RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_END,0,1)
end
function c100911074.tdop(e,tp,eg,ep,ev,re,r,rp)
	local tg=Duel.GetChainInfo(0,CHAININFO_TARGET_CARDS)
	if not e:GetHandler():IsRelateToEffect(e) or not tg or tg:FilterCount(Card.IsRelateToEffect,nil,e)~=2 then return end
	Duel.SendtoDeck(tg,nil,0,REASON_EFFECT)
	local g=Duel.GetOperatedGroup()
	if g:IsExists(Card.IsLocation,1,nil,LOCATION_DECK) then Duel.ShuffleDeck(tp) end
	local ct=g:FilterCount(Card.IsLocation,nil,LOCATION_DECK+LOCATION_EXTRA)
	if ct==2 then
		Duel.BreakEffect()
		Duel.Draw(tp,1,REASON_EFFECT)
	end
end
