--电影之骑士 盖亚剑士
function c101001051.initial_effect(c)
	Debug.Message("「电影之骑士 盖亚剑士」暂时无法使用！")
end
