--魂のカード
--Card of Soul
--Script by nekrozar
function c100909068.initial_effect(c)
	--Activate
	local e1=Effect.CreateEffect(c)
	e1:SetCategory(CATEGORY_TOHAND+CATEGORY_SEARCH)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_FREE_CHAIN)
	e1:SetCountLimit(1,100909068+EFFECT_COUNT_CODE_OATH)
	e1:SetTarget(c100909068.target)
	e1:SetOperation(c100909068.activate)
	c:RegisterEffect(e1)
end
function c100909068.target(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.GetFieldGroupCount(tp,LOCATION_DECK,0)>0 end
	Duel.SetOperationInfo(0,CATEGORY_TOHAND,nil,1,0,LOCATION_DECK)
end
function c100909068.filter(c,lp)
	return c:GetAttack()+c:GetDefence()==lp and c:IsAbleToHand()
end
function c100909068.activate(e,tp,eg,ep,ev,re,r,rp)
	local g=Duel.GetFieldGroup(tp,LOCATION_DECK,0)
	if g:GetCount()<1 then return end
	Duel.ConfirmCards(tp,g)
	local lp=Duel.GetLP(tp)
	if g:IsExists(c100909068.filter,1,nil,lp) and Duel.SelectYesNo(tp,aux.Stringid(100909068,0)) then
		Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_ATOHAND)
		local sg=g:FilterSelect(tp,c100909068.filter,1,1,nil,lp)
		Duel.SendtoHand(sg,nil,REASON_EFFECT)
		Duel.ConfirmCards(1-tp,sg)
		Duel.ShuffleHand(tp)
	end
	Duel.ShuffleDeck(tp)
end
