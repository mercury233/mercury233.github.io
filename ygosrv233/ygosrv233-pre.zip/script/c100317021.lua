--电脑网宇宙
function c100317021.initial_effect(c)
	Debug.Message("「电脑网宇宙」暂时无法使用！")
end
