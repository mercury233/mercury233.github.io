--解码语者
function c100317041.initial_effect(c)
	Debug.Message("「解码语者」暂时无法使用！")
end
